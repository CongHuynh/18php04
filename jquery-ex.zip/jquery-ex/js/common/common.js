// JavaScript Document
$('#yes , #no').click(function(){
        
	if($('#yes').text() == 'yes'){
		$('.demo').text('Có');
		
	}else{
		$('.demo').text('Có');
	}
});