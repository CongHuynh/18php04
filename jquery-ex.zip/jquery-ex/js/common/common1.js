// JavaScript Document

$('#accost').click(function(){
	  
		$('.boy').animate({left:'450px'},2000);
    	$('.girl').animate({right:'250px'},2000);
	
});
$('#flower').click(function(){
	  
		$('.boy').attr('src','img/flower.jpg');
	
	
});